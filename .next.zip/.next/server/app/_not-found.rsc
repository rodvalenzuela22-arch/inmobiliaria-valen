1:"$Sreact.fragment"
2:I[9766,[],""]
3:I[8924,[],""]
4:I[4431,[],"OutletBoundary"]
6:I[5278,[],"AsyncMetadataOutlet"]
8:I[4431,[],"ViewportBoundary"]
a:I[4431,[],"MetadataBoundary"]
b:"$Sreact.suspense"
d:I[4062,["4219","static/chunks/app/global-error-2d277151d6ca4b16.js"],"default"]
:HL["/_next/static/css/2437476231a19174.css","style"]
:HC"https://luxlausvpqkatqdteavk.supabase.co"
0:{"P":null,"b":"PDOXv6WGfy7fcnVYarcRG","p":"","c":["","_not-found"],"i":false,"f":[[["",{"children":["/_not-found",{"children":["__PAGE__",{}]}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/2437476231a19174.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"es-AR","className":"__variable_1243c3 __variable_81ca43","children":["$","body",null,{"children":["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","main",null,{"className":"mx-auto max-w-2xl px-4 py-24 text-center","children":[["$","h1",null,{"className":"text-3xl font-semibold","children":"No encontramos esa página"}],["$","p",null,{"className":"mt-3 text-tinta/80","children":"El enlace puede ser incorrecto o la página ya no existe."}],["$","a",null,{"href":"/","className":"btn-primary mt-6","children":"Ir al inicio"}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],{"children":["/_not-found",["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":["__PAGE__",["$","$1","c",{"children":[["$","main",null,{"className":"mx-auto max-w-2xl px-4 py-24 text-center","children":[["$","h1",null,{"className":"text-3xl font-semibold","children":"No encontramos esa página"}],["$","p",null,{"className":"mt-3 text-tinta/80","children":"El enlace puede ser incorrecto o la página ya no existe."}],["$","a",null,{"href":"/","className":"btn-primary mt-6","children":"Ir al inicio"}]]}],null,["$","$L4",null,{"children":["$L5",["$","$L6",null,{"promise":"$@7"}]]}]]}],{},null,false]},null,false]},null,false],["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],[["$","$L8",null,{"children":"$L9"}],null],["$","$La",null,{"children":["$","div",null,{"hidden":true,"children":["$","$b",null,{"fallback":null,"children":"$Lc"}]}]}]]}],false]],"m":"$undefined","G":["$d",[]],"s":false,"S":true}
9:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
5:null
7:{"metadata":[["$","title","0",{"children":"Inmobiliaria"}]],"error":null,"digest":"$undefined"}
c:"$7:metadata"
